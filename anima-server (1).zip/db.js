const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'data.json');

function blank() {
  return { users: {}, handles: {}, pubkeys: {}, messages: [], blocked: {} };
}

let data = blank();
if (fs.existsSync(FILE)) {
  try { data = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch (e) { data = blank(); }
}
for (const k of Object.keys(blank())) if (!(k in data)) data[k] = blank()[k];

let saveQueued = false;
function save() {
  if (saveQueued) return;
  saveQueued = true;
  setImmediate(() => {
    saveQueued = false;
    fs.writeFileSync(FILE, JSON.stringify(data), 'utf8');
  });
}

module.exports = { data, save };
