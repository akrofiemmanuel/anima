const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { WebSocketServer } = require('ws');
const { data, save } = require('./db');

const SECRET_FILE = path.join(__dirname, '.jwt-secret');
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (fs.existsSync(SECRET_FILE)) JWT_SECRET = fs.readFileSync(SECRET_FILE, 'utf8').trim();
  else { JWT_SECRET = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(SECRET_FILE, JWT_SECRET); }
}

const app = express();
app.use(express.json({ limit: '256kb' }));
app.use(express.static(path.join(__dirname, 'public')));

function convId(a, b) { return [a, b].sort().join('~'); }

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'no token' });
  try { req.userId = jwt.verify(token, JWT_SECRET).id; next(); }
  catch (e) { return res.status(401).json({ error: 'invalid token' }); }
}

// ---------- rate limiting (basic, in-memory, per-IP) ----------
const hits = new Map();
function rateLimit(max, windowMs) {
  return (req, res, next) => {
    const key = req.ip + ':' + req.path;
    const now = Date.now();
    const arr = (hits.get(key) || []).filter(t => now - t < windowMs);
    if (arr.length >= max) return res.status(429).json({ error: 'too many requests, slow down' });
    arr.push(now); hits.set(key, arr);
    next();
  };
}

// ---------- accounts ----------
app.post('/api/signup', rateLimit(5, 60000), async (req, res) => {
  const { handle, password } = req.body || {};
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(handle || '')) return res.status(400).json({ error: '3-20 letters, numbers or _' });
  if (!password || password.length < 8) return res.status(400).json({ error: 'password must be 8+ characters' });
  const lower = handle.toLowerCase();
  if (data.handles[lower]) return res.status(409).json({ error: 'account name taken' });
  const id = crypto.randomUUID();
  const passwordHash = await bcrypt.hash(password, 12);
  data.users[id] = { id, handle, handleLower: lower, passwordHash, createdAt: Date.now() };
  data.handles[lower] = id;
  save();
  const token = jwt.sign({ id }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, id, handle });
});

app.post('/api/login', rateLimit(10, 60000), async (req, res) => {
  const { handle, password } = req.body || {};
  const id = data.handles[(handle || '').toLowerCase()];
  const user = id && data.users[id];
  if (!user || !(await bcrypt.compare(password || '', user.passwordHash))) {
    return res.status(401).json({ error: 'wrong account name or password' });
  }
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '30d' });
  res.json({ token, id: user.id, handle: user.handle });
});

app.get('/api/search', auth, (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  if (!q) return res.json([]);
  const blockedByMe = new Set(data.blocked[req.userId] || []);
  const results = Object.values(data.users)
    .filter(u => u.id !== req.userId && !blockedByMe.has(u.id) && u.handleLower.includes(q))
    .slice(0, 8)
    .map(u => ({ id: u.id, handle: u.handle }));
  res.json(results);
});

// ---------- public keys (ECDH identity keys, published so peers can key-exchange) ----------
app.post('/api/pubkey', auth, (req, res) => {
  const { pubKey } = req.body || {};
  if (!pubKey) return res.status(400).json({ error: 'pubKey required' });
  data.pubkeys[req.userId] = pubKey;
  save();
  res.json({ ok: true });
});
app.get('/api/pubkey/:id', auth, (req, res) => {
  const pk = data.pubkeys[req.params.id];
  if (!pk) return res.status(404).json({ error: 'no key published' });
  res.json({ pubKey: pk });
});

// ---------- blocking ----------
app.post('/api/block', auth, (req, res) => {
  const { peerId, blocked } = req.body || {};
  const list = new Set(data.blocked[req.userId] || []);
  if (blocked) list.add(peerId); else list.delete(peerId);
  data.blocked[req.userId] = [...list];
  save();
  res.json({ ok: true });
});

// ---------- conversations (derived from messages — no separate contacts table,
// so a chat someone else started with you shows up automatically) ----------
app.get('/api/conversations', auth, (req, res) => {
  const me = req.userId;
  const blockedByMe = new Set(data.blocked[me] || []);
  const seen = new Map();
  for (const m of data.messages) {
    if (m.from !== me && m.to !== me) continue;
    const peerId = m.from === me ? m.to : m.from;
    if (blockedByMe.has(peerId)) continue;
    const prev = seen.get(peerId);
    if (!prev || m.ts > prev.ts) seen.set(peerId, { peerId, ts: m.ts });
  }
  const out = [...seen.values()]
    .sort((a, b) => b.ts - a.ts)
    .map(c => ({ id: c.peerId, handle: (data.users[c.peerId] || {}).handle || 'unknown' }));
  res.json(out);
});

// ---------- messages ----------
function purgeExpired() {
  const now = Date.now();
  const before = data.messages.length;
  data.messages = data.messages.filter(m => !(m.expiresAt && now > m.expiresAt));
  if (data.messages.length !== before) save();
}

app.get('/api/messages', auth, (req, res) => {
  purgeExpired();
  const conv = req.query.conv;
  const [a, b] = (conv || '').split('~');
  if (req.userId !== a && req.userId !== b) return res.status(403).json({ error: 'not your conversation' });
  const msgs = data.messages.filter(m => m.conv === conv);
  for (const m of msgs) if (m.from !== req.userId && !m.readAt) m.readAt = Date.now();
  save();
  res.json(msgs);
});

app.post('/api/messages', auth, rateLimit(30, 10000), (req, res) => {
  const { to, cipher, iv, dhPub, rotated, expiresInSec } = req.body || {};
  if (!to || !cipher || !iv) return res.status(400).json({ error: 'missing fields' });
  const blockedByThem = new Set(data.blocked[to] || []);
  if (blockedByThem.has(req.userId)) return res.status(403).json({ error: 'blocked' });
  const msg = {
    id: crypto.randomUUID(), conv: convId(req.userId, to), from: req.userId, to,
    cipher, iv, dhPub: dhPub || null, rotated: !!rotated, ts: Date.now(),
  };
  if (expiresInSec) msg.expiresAt = Date.now() + expiresInSec * 1000;
  data.messages.push(msg);
  save();
  broadcast(req.userId, msg);
  broadcast(to, msg);
  res.json(msg);
});

app.delete('/api/messages/:id', auth, (req, res) => {
  const idx = data.messages.findIndex(m => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'not found' });
  const m = data.messages[idx];
  if (m.from !== req.userId) return res.status(403).json({ error: 'not yours' });
  data.messages.splice(idx, 1);
  save();
  broadcastDelete(m.from, m.id); broadcastDelete(m.to, m.id);
  res.json({ ok: true });
});

app.post('/api/burn', auth, (req, res) => {
  const { conv } = req.body || {};
  const [a, b] = (conv || '').split('~');
  if (req.userId !== a && req.userId !== b) return res.status(403).json({ error: 'not your conversation' });
  const removed = data.messages.filter(m => m.conv === conv);
  data.messages = data.messages.filter(m => m.conv !== conv);
  save();
  for (const m of removed) { broadcastDelete(m.from, m.id); broadcastDelete(m.to, m.id); }
  res.json({ ok: true, removed: removed.length });
});

setInterval(purgeExpired, 15000);

// ---------- realtime: new messages + typing indicator, pushed over WebSocket ----------
const server = app.listen(process.env.PORT || 3000, () => {
  console.log('Anima server listening on :' + (process.env.PORT || 3000));
});
const wss = new WebSocketServer({ server, path: '/ws' });
const sockets = new Map(); // userId -> Set<ws>

function broadcast(userId, msg) {
  for (const ws of sockets.get(userId) || []) if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'message', msg }));
}
function broadcastDelete(userId, id) {
  for (const ws of sockets.get(userId) || []) if (ws.readyState === 1) ws.send(JSON.stringify({ type: 'delete', id }));
}

wss.on('connection', (ws, req) => {
  let userId = null;
  try {
    const url = new URL(req.url, 'http://x');
    userId = jwt.verify(url.searchParams.get('token') || '', JWT_SECRET).id;
  } catch (e) { ws.close(); return; }
  if (!sockets.has(userId)) sockets.set(userId, new Set());
  sockets.get(userId).add(ws);
  ws.on('message', raw => {
    try {
      const { type, to, conv } = JSON.parse(raw);
      if (type === 'typing' && to) {
        for (const peerWs of sockets.get(to) || []) if (peerWs.readyState === 1) peerWs.send(JSON.stringify({ type: 'typing', conv, from: userId }));
      }
    } catch (e) {}
  });
  ws.on('close', () => { const s = sockets.get(userId); if (s) { s.delete(ws); if (!s.size) sockets.delete(userId); } });
});
