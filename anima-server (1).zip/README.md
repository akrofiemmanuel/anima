# Anima — real backend

A self-contained Node.js server: real password accounts (bcrypt-hashed), JWT
sessions, a JSON-file database, and a WebSocket relay for real-time,
end-to-end encrypted messaging. The server only ever sees ciphertext — all
encryption/decryption happens in the browser (public/index.html).

## Run it locally

```
npm install
npm start
```

Then open http://localhost:3000 — create two accounts (use a second browser
profile or incognito window for the second one) and chat between them.

## Deploy it for real (so anyone can open a link)

Any host that runs Node.js works. Two free/cheap options that need no config
beyond "point it at this folder":

**Render.com**
1. Push this folder to a GitHub repo.
2. New → Web Service → connect the repo.
3. Build command: `npm install`  ·  Start command: `npm start`
4. Deploy. You'll get a `https://your-app.onrender.com` URL — that's your
   real, shareable link.

**Railway.app** — same idea: connect the repo, it detects Node automatically,
deploy, you get a public URL.

**Your own VPS** — copy this folder up, run `npm install && npm start`
behind a reverse proxy (Caddy or nginx) for HTTPS, or just use the included
Dockerfile:
```
docker build -t anima .
docker run -p 3000:3000 -v $(pwd)/data:/app/data anima
```

## Data & secrets

- `data.json` is the whole database (created on first run). Back it up if you
  care about the messages/accounts in it.
- `.jwt-secret` is generated on first run and signs login sessions — don't
  commit it, and don't lose it (losing it logs everyone out).
- Set `JWT_SECRET` as an environment variable on your host instead, if you'd
  rather not rely on a file (recommended for real deployments).

## What's real here vs. the claude.ai version

Same encryption design (ECDH P-256 identity keys, AES-256-GCM, a per-sender
forward-secrecy ratchet, and a DH ratchet step for post-compromise security)
— all client-side code carried over unchanged. What's different is the
account layer: real handle+password signup instead of piggybacking on a
Claude login, a real always-on server instead of Claude's artifact runtime,
and a database that persists independently of any one platform.

## Known limitations (still true here, not fixed by having a real backend)

- The crypto protocol is hand-built for this project, not an audited library
  — see the earlier discussion of why that's the single biggest risk if this
  is ever used for anything that actually matters.
- Metadata (who messaged whom, when) is visible to whoever runs the server —
  message *content* is what's encrypted.
- No group chats, attachments, or push notifications yet.
- Rate limiting is basic and in-memory (per-process) — fine for one server,
  won't survive being load-balanced across multiple instances without change.
